const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const rootDir = require('./util/path');
const userRoutes = require('./routes/user');
const sequelize = require('./util/database');
const User = require('./models/User');

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(rootDir, 'public')));
app.use(bodyParser.json());

app.use(userRoutes);

sequelize.sync({ force: false })
    .then(() => console.log('Databasse & tables created!'))
    .catch(err => console.log('An error occured'));


app.get('/', (req, res) => {
    res.sendFile(__dirname + '/signup.html');
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`server is running on port ${PORT}`);
})