const path = require('path');
const User = require('../models/User');
const bcrypt = require('bcrypt');
const { use } = require('../routes/user');

exports.addUser = async (req, res, next) => {
    try{
        const { username, email, password } = req.body;

        if(!username || !email || !password) {
            return res.status(400).json({ error: 'Bad parameters: somthing is missing' });
        }

        const saltrounds = 10;
        bcrypt.hash(password, saltrounds, async (err, hash) => {
            console.log(err)
            await User.create({ username, email, password: hash });
            res.sendFile(path.join(__dirname, '../signup.html'));
        })
    } catch(err)  {
        console.error('Error creating user:', err);
        res.status(500).send('Error creating user');
    };
};

exports.userLogin = async (req, res, next) => {
    const { email, password } = req.body;

    if(!email || !password){
        return res.status(400).json({ error: 'Bad parameters: Email Id or Password is missing' });
    }

    try {
        const user = await User.findOne({ where: { email: email }});
        if(user) {
            const passwordMatch = await bcrypt.compare(password, user.password);
            if(passwordMatch) {
                return res.status(200).json({ message: 'User loggged in successfully' });
            } else {
                return res.status(400).json({ error: 'Password is incorrect' });
            }
        } else {
            return res.status(400).json({ error: 'User does not exist' });
        }
    } catch (err) {
        console.log('Error while logging in:', err);
        res.status(500).send('Error while logging in');
    }
};