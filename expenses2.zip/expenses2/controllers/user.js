const path = require('path');
const User = require('../models/User');

exports.addUser = async (req, res, next) => {
    try{
        const { username, email, password } = req.body;

        if(!username || !email || !password) {
            return res.status(400).json({ error: 'Bad parameters: somthing is missing' });
        }
        const user = await User.create({ username, email, password });
        console.log('User created:', user);
        res.sendFile(path.join(__dirname, '../signup.html'));
    } catch(err)  {
        console.error('Error creating user:', err);
        res.status(500).send('Error creating user');
    };
};

exports.userLogin = async (req, res, next) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ where: { email: email, password: password } });

        if(user) {
            return res.send('Welcome, ' + user.username);
        } else {
            res.status(401).send('Inavlid email or password');
        }
    } catch (err) {
        console.log('Error while logging in:', err);
        res.status(500).send('Error while logging in');
    }
};